<?php
return [
    'db_host' => 'localhost',
    'db_name' => 'intelboard_core',
    'db_user' => 'intelboard_user',
    'db_pass' => '000000xz',
    'db_charset' => 'utf8mb4',
];