    </div> <!-- end layout-wrapper -->

    <script src="/views/assets/js/bootstrap.bundle.min.js"></script>
    <script src="/views/assets/js/app.min.js"></script>
</body>
</html>