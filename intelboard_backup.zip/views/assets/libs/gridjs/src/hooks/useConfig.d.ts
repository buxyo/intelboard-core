import { Config } from '../config';
export declare function useConfig(): Config;
