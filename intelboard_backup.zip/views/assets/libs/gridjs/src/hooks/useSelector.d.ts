export default function useSelector<T>(selector: (state: any) => T): T;
