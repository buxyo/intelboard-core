export declare function useStore(): import("../state/store").Store<Record<string, unknown>>;
