export declare function width(width: string | number, containerWidth?: number): number;
export declare function px(width: number): string;
