import { h } from 'preact';
export declare function HeaderContainer(): h.JSX.Element;
