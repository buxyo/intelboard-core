import { h } from 'preact';
export declare function FooterContainer(): h.JSX.Element;
