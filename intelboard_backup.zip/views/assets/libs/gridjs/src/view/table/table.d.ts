import { h } from 'preact';
export declare function Table(): h.JSX.Element;
