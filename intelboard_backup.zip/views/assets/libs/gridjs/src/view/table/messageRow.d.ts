import { h } from 'preact';
export declare function MessageRow(props: {
    message: string;
    colSpan?: number;
    className?: string;
}): h.JSX.Element;
