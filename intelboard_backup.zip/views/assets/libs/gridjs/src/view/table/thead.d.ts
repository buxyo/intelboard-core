import { h } from 'preact';
export declare function THead(): h.JSX.Element;
