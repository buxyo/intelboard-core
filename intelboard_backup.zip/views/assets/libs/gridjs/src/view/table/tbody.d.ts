import { h } from 'preact';
export declare function TBody(): h.JSX.Element;
