import { h } from 'preact';
export declare function Container(): h.JSX.Element;
