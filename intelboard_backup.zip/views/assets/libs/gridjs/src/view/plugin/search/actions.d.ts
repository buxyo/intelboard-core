export declare const SearchKeyword: (payload: any) => (state: any) => any;
