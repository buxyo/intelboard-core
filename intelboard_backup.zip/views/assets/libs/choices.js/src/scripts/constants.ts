export const SCROLLING_SPEED: number = 4 as const;
