<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <h4><?= Lang::get('dashboard.welcome') ?></h4>
            <!-- Add your dashboard cards here -->
        </div>
    </div>
</div>